This documentation is also available as html version at
http://www.ambiera.com/irrklang